package Features;

import runapp.NotificationService;
import DataAccess.IAccountRepository;
import domain.Services.INotificationService;
import domain.Account;
import domain.Guid;

public class TransferMoney {
    private IAccountRepository accountRepository;
    private INotificationService notificationService;

    public TransferMoney(IAccountRepository accountRepository,
            NotificationService notifier) {
        this.accountRepository = accountRepository;
        this.notificationService = notifier;
    }
    
    public void execute(Guid fromAccountId, Guid toAccountId, double amount){
        Account fromAccount = accountRepository.GetAccountById(fromAccountId);
        Account toAccount = accountRepository.GetAccountById(toAccountId);
        
        double balanceAfterDeduction = fromAccount.getBalance() - amount;
        //Insufficient Balance at Senders
        if (balanceAfterDeduction <0){
            throw new IllegalStateException("Insufficient funds to make transfer");
        }
        
        //Sender's low funds notification
        if (balanceAfterDeduction<500){
            this.notificationService.NotifyFundsLow(fromAccount.getUser().getEmail());
        } 
        
        // Receivers reached paid in limit
        if (toAccount.getPaidIn()+amount > Account.getPayInLimit()){
            throw new IllegalStateException("Account paid in limit reached");
        }
        
        // Receivers notification for approaching pay in Limit
        if (Account.getPayInLimit() - (amount+toAccount.getPaidIn()) <500){
            this.notificationService.NotifyApproachingPayInLimit(toAccount.getUser().getEmail());
        }
        
        fromAccount.withdrawn(amount);
        toAccount.paidIn(amount);
                
        this.accountRepository.Update(fromAccount);
        this.accountRepository.Update(toAccount);
    }
}
