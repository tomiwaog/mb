package Features;

import java.util.NoSuchElementException;

import runapp.NotificationService;
import DataAccess.IAccountRepository;
import domain.Services.INotificationService;
import domain.Account;
import domain.Guid;

public class WithdrawMoney {
    private IAccountRepository accountRepository;
    private INotificationService notificationService;

    public WithdrawMoney(IAccountRepository accountRepository,
            NotificationService notifier) {
        this.accountRepository = accountRepository;
        this.notificationService = notifier;
    }

    public void execute(Guid fromAccountId, double amount) {
        Account userAccount = accountRepository.GetAccountById(fromAccountId);
        if (userAccount==null) throw new NoSuchElementException("Could not find the account with Guuid"+fromAccountId.toString());
        if (amount<0) throw new IllegalArgumentException("Amount to withraw must be a positive number");
        
        double afterWithrawalAccount = userAccount.getBalance()-amount;
        //Insufficient Amount in account
        if (afterWithrawalAccount<0){
            throw new IllegalStateException("Insufficient balance. Withdrawal failed!");
        }
        //Low funds notification
        if (afterWithrawalAccount<500){
            this.notificationService.NotifyFundsLow(userAccount.getUser().getEmail());
        }
        
        userAccount.withdrawn(amount);
        this.accountRepository.Update(userAccount);
    }
}
