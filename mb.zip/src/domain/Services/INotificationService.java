package domain.Services;

public interface INotificationService
{
    void NotifyApproachingPayInLimit(String emailAddress);

    void NotifyFundsLow(String emailAddress);
}
