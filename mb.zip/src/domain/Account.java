package domain;

public class Account {
    private static final double payInLimit = 4000;
    private Guid id;
    private User user = null;
    private double balance;
    private double paidIn;
    
    public Guid getId() {
        return id;
    }
    
    public Account(){
        this(0);
    }
    public Account(double balance){
        if (balance<0) this.balance=0;
        this.balance = balance;
        id = new Guid();
    }
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        if (user==null) return;
        this.user = user;
    }

    public double getBalance() {
        return balance;
    }
    
    public void withdrawn(double amount){
        if (amount>balance) return;
        this.balance-=amount;
        this.paidIn -=amount;
    }
    
    public void paidIn(double amount){
        if (amount+paidIn> payInLimit)return;
        this.balance+=amount;
        this.paidIn +=amount;
    }
    
    public double getPaidIn(){
       return paidIn;
    }
    public static double getPayInLimit() {
        return payInLimit;
    }
    
}
