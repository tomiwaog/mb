package domain;

import java.util.UUID;

public class Guid {
    private UUID uuid;
    
    Guid(){
        uuid =UUID.randomUUID();
    }  
    
    @Override public String toString(){
        return uuid.toString();
    }
}
