package test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import domain.Account;

public class TestAccount {
    Account user;
    
    @Before
    public void init(){
        user = new Account(200);
    }
    
    @After
    public void finalise(){
        user =null;
    }
    
    
    @Test
    public void testUnderPaidInLimit(){
        user.paidIn(500);
        user.paidIn(3500);
        Assert.assertEquals(4000, user.getPaidIn(), 0f);
    }
    
    @Test
    public void testOverPaidInLimit(){
        user.paidIn(500);
        user.paidIn(3501);
        Assert.assertEquals(500, user.getPaidIn(), 0f);
    }
    @Test
    public void testPaidIn(){
        double topUp = 500;
        user.paidIn(topUp);
        user.paidIn(topUp);
        Assert.assertEquals(topUp*2, user.getPaidIn(), 0f);
    }
    
    
}
