package test;


import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import DataAccess.IAccountRepository;
import Features.WithdrawMoney;
import runapp.AccountRepository;
import runapp.NotificationService;
import domain.Account;
import domain.User;

public class TestWithdrawMoney {
    IAccountRepository accountRepo = new AccountRepository();
    
    WithdrawMoney moneyWithdrawal ;
    AccountRepository repo;
    NotificationService notifier;
    Account accOne;
    
    @Before
    public void init(){
        repo = new AccountRepository();
        notifier = new NotificationService();
        moneyWithdrawal = new WithdrawMoney(repo, notifier);
    }
    
    @After
    public void finalize(){
        repo=null;
    }
    
    @Test
    public void testValidWithdrawal(){
        accOne = new Account(600);
        accOne.setUser(new User("User One"));
        repo.addAccount(accOne);
        moneyWithdrawal.execute(accOne.getId(), 499);
        moneyWithdrawal.execute(accOne.getId(), 101);
        Assert.assertEquals(0.0, accOne.getBalance(), 0f);
    }
    
    @Test
    public void testInsufficcientBalanceWithdrawal(){
        accOne = new Account(700);
        accOne.setUser(new User("User One"));
        repo.addAccount(accOne);
        moneyWithdrawal.execute(accOne.getId(), 100);
        try{
            moneyWithdrawal.execute(accOne.getId(), 600);
        }catch(IllegalStateException e){
            Assert.assertTrue(accOne.getBalance()==400.00);
        } 
    }
    
    @Test
    public void testNegativeAmountWithdrawal(){
        accOne = new Account(600);
        accOne.setUser(new User("User One"));
        repo.addAccount(accOne);
        try{
            moneyWithdrawal.execute(accOne.getId(), -100);
        }catch(IllegalArgumentException e){
            Assert.assertTrue(accOne.getBalance()==600.00);
        }
    }
}
