package test;

import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import Features.TransferMoney;
import runapp.AccountRepository;
import runapp.NotificationService;
import domain.Account;
import domain.User;

public class TestMoneyTransfer {
    TransferMoney moneyTransfer ;
    AccountRepository repo;
    NotificationService notifier;
    Account accOne, accTwo;
    
    @Before
    public void init(){
        repo = new AccountRepository();
        notifier = new NotificationService();
        moneyTransfer = new TransferMoney(repo, notifier);
    }
    
    @After
    public void finalize(){
        repo=null;
    }
    
    @Test
    public void testValidTransfer(){
        accOne = new Account(3000);
        accOne.setUser(new User("User One"));
        accTwo = new Account(1000);
        accTwo.setUser(new User("User Two"));
        repo.addAccount(accOne);
        repo.addAccount(accTwo);
        moneyTransfer.execute(accOne.getId(), accTwo.getId(), 1000);
        Assert.assertTrue(accOne.getBalance()==2000.00);
        Assert.assertTrue(accTwo.getBalance()==2000.00);
    }
    
    @Test
    public void testInvalidRecipient(){
        accOne = new Account(3000);
        accOne.setUser(new User("User One"));
        accTwo = new Account(1000);
        accTwo.setUser(new User("User Two"));
        repo.addAccount(accOne);
        try{
            moneyTransfer.execute(accOne.getId(), accTwo.getId(), 1000);
        }catch(NoSuchElementException e){
            Assert.assertTrue(accOne.getBalance()==3000.00);
            Assert.assertTrue(accTwo.getBalance()==1000.00);
        }  
    }
    
    @Test
    public void testBreachedPayInLimit(){
        accOne = new Account(5000);
        accOne.setUser(new User("User One"));
        accTwo = new Account(1000);
        accTwo.setUser(new User("User Two"));
        repo.addAccount(accOne);
        repo.addAccount(accTwo);
        moneyTransfer.execute(accOne.getId(), accTwo.getId(), 2000);
        try{
            moneyTransfer.execute(accOne.getId(), accTwo.getId(), 2001);
        }catch(IllegalStateException e){
            Assert.assertTrue(accOne.getBalance()==3000.00);
            Assert.assertTrue(accTwo.getBalance()==3000.00);
        }  
    }
    
    @Test
    public void testInsufficientBalanceTransferException(){
        accOne = new Account(3000);
        accOne.setUser(new User("User One"));
        accTwo = new Account(1000);
        accTwo.setUser(new User("User Two"));
        repo.addAccount(accOne);
        repo.addAccount(accTwo);
        try{
            moneyTransfer.execute(accOne.getId(), accTwo.getId(), 3001);
        }catch (RuntimeException e){
            Assert.assertTrue(e instanceof IllegalStateException);
            Assert.assertTrue(accOne.getBalance()==3000.00);
            Assert.assertTrue(accTwo.getBalance()==1000.00);
        }   
    }
}
