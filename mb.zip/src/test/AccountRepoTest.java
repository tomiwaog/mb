package test;

import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import runapp.AccountRepository;
import domain.Account;
import domain.User;

public class AccountRepoTest {
    AccountRepository repo;
    Account accOne, account;

    @Before
    public void init() {
        repo = new AccountRepository();
    }

    @After
    public void finalize() {
        repo = null;
        account =null;
    }

    @Test
    public void testGetValidAccount() {
        accOne = new Account(3000);
        accOne.setUser(new User("User One"));
        repo.addAccount(accOne);
        account = repo.GetAccountById(accOne.getId());
        Assert.assertTrue(account != null);
    }

    @Test
    public void testInvalidAccount() {
        accOne = new Account(3000);
        accOne.setUser(new User("User One"));
        account=null;
        try {
            account = repo.GetAccountById(accOne.getId());
        } catch (NoSuchElementException e) {
            Assert.assertTrue(account == null);
        }
    }
}
