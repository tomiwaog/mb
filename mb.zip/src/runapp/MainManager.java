package runapp;

import java.util.NoSuchElementException;

import Features.TransferMoney;
import domain.Account;
import domain.User;

public class MainManager {

    public static void main(String[] args) {

        // Accounts Set up
        Account basicOne = new Account(5000);
        User johnDoe = new User("johndoe@example.com", "John Doe");
        basicOne.setUser(johnDoe);

        Account basicTwo = new Account(1000);
        User jadeDoe = new User("janedoe@example.com");
        basicTwo.setUser(jadeDoe);

        Account unknown = new Account();
        User TomSmith = new User("foreignAccount@example.com", "Unknown User");
        unknown.setUser(TomSmith);

        // Account Features Test
        NotificationService notifierService = new NotificationService();
        AccountRepository xBranchAccountRepo = new AccountRepository();

        // Add account to Repository
        xBranchAccountRepo.addAccount(basicOne);
        xBranchAccountRepo.addAccount(basicTwo);

        // User Deposits
        try {
            // Check User balance
            System.out.println("John Doe's " + basicOne.getBalance());
            System.out.println("Jane Doe's " + basicTwo.getBalance());

            // Transfer funds from userA to userB
            TransferMoney transferTool = new TransferMoney(xBranchAccountRepo,
                    notifierService);
            transferTool.execute(basicOne.getId(), unknown.getId(), 4001);
            
            // Check User balance after withdrawal
            System.out.println("John Doe's " + basicOne.getBalance());
            System.out.println("Jane Doe's " + unknown.getBalance());
            
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
        }catch(IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
        catch(NoSuchElementException e){
            System.out.println(e.getMessage());
        }
        catch(RuntimeException e){
            System.out.println(e.getMessage());
        }


    }
}
