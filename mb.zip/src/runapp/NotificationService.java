package runapp;

import domain.Services.INotificationService;

public class NotificationService implements INotificationService{
    @Override
    public void NotifyApproachingPayInLimit(String emailAddress) {
        System.out.printf("Notified user '%s' for approaching pay in limit\n", emailAddress);
    }

    @Override
    public void NotifyFundsLow(String emailAddress) {
        System.out.printf("Notified user '%s' for having low funds\n", emailAddress);
    }
}