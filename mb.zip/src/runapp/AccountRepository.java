package runapp;

import java.util.HashMap;
import java.util.NoSuchElementException;

import DataAccess.IAccountRepository;
import domain.Account;
import domain.Guid;

public class AccountRepository implements IAccountRepository{
    private HashMap<String,Account> accountsDB = new HashMap<>(); //Hash Storage used for instant retrieval
    
    @Override
    public Account GetAccountById(Guid accountId) {
        //Getting account in O(1) constant runtime.
        String uuid = accountId.toString();
        Account getAccount = accountsDB.get(uuid);
        if (getAccount==null) throw new NoSuchElementException("Could not find account match the GUID"+ accountId.toString());        
        return getAccount;
    }

    @Override 
    public void Update(Account account) {
         accountsDB.replace(account.getId().toString(), account);
    }

    public boolean addAccount(Account basicOne) {
        if (basicOne==null) return false;
        String accountGuid = basicOne.getId().toString();
        if (accountsDB.containsKey(accountGuid)) return false;
        accountsDB.put(accountGuid, basicOne);
        return true;
    }

}
