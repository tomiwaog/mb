package DataAccess;

import domain.Account;
import domain.Guid;

public interface IAccountRepository {
    Account GetAccountById(Guid accountId);
    
    void Update(Account account);
}
